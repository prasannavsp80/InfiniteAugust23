package com.java.thr;

public enum LeaveType {

	EL, PL, ML
}
