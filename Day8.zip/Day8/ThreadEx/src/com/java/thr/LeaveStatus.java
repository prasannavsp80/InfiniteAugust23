package com.java.thr;

public enum LeaveStatus {
	PENDING, ACCEPTED, REJECTED
}
