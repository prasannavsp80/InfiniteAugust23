package com.java.servlets;

public enum Gender {
	MALE, FEMALE
}
