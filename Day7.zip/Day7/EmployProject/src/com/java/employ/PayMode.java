package com.java.employ;

public enum PayMode {
	MONTHLY, HALFYEARLY, YEARLY, QUARTERLY
}
