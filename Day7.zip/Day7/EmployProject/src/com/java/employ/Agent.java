package com.java.employ;

public class Agent {

	private int agentId;
	private String firstName;
	private String lastName;
	private String city;
	private PayMode payMode;
	private double premium;
}
