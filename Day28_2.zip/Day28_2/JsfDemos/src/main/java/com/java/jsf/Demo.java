package com.java.jsf;

public class Demo {

	public String redirect() {
		return "Menu.jsp?faces-redirect=true";
	}
}
