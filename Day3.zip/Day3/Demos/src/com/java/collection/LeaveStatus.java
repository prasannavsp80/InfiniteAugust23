package com.java.collection;

public enum LeaveStatus {

	EL, PL, ML
}
