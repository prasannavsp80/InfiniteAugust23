package com.java.oops;

public class Hackthon {

	String name;
	
	public void setLanguage(String name) {
		System.out.println("Hi " +name+ " You can take test in Java/Python/Javascript");
	}
	
	public void setLimit() {
		System.out.println("Hi 30 Users allowed at once...");
	}
}
