package com.java.oops;

public class Training {

	String topic;
	
	public Training(String topic) {
		this.topic = topic;
	}

	@Override
	public String toString() {
		return "Training [topic=" + topic + "]";
	}
	
	
}
