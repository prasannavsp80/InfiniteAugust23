package com.java.oops;

public class Angular extends Training {

	public Angular(String topic) {
		super(topic);
		// TODO Auto-generated constructor stub
	}

}
