package com.java.oops;

public class Java extends Training {

	public Java(String topic) {
		super(topic);
		// TODO Auto-generated constructor stub
	}
	
}
