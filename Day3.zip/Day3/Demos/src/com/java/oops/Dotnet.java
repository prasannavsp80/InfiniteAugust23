package com.java.oops;

public class Dotnet extends Training {

	public Dotnet(String topic) {
		super(topic);
		// TODO Auto-generated constructor stub
	}

}
