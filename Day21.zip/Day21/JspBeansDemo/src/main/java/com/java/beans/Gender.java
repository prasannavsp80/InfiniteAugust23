package com.java.beans;

public enum Gender {
	MALE, FEMALE
}
