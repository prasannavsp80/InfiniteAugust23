package com.infinite.cms;

public enum OrderStatus {

	ACCEPTED, DENIED, PENDING
}
