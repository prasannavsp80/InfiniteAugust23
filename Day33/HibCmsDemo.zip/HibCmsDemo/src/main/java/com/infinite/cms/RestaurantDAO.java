package com.infinite.cms;

import java.util.List;

public interface RestaurantDAO {

	List<Restaurant> showRestaurantDao();
	List<String> showRestaurantNames();
}
