package com.infinite.cms;

import java.util.List;

public interface MenuDAO {

	List<Menu> showMenuByRestaurant(int rid);
}
