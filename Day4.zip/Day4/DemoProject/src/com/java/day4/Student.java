package com.java.day4;

public class Student {

	private int studentId;
	private String name;
	private String city;
	private double cgp;
	
	// sort by 1) Name-wise 2) cgp wise 
}
