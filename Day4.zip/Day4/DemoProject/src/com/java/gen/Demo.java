package com.java.gen;

public class Demo {

	public static void main(String[] args) {
		int a=12, b=13;
		Data obj = new Data();
		obj.swap(a, b);
		double a1=12.5, b1=5.2;
		obj.swap(a1, b1);
		String s1="Sourav", s2="Ayush";
		obj.swap(s1, s2);
	}
}
