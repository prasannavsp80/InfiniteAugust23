package com.java.exam;

public class MobileFactory extends AbstractFactory {

	@Override
	public Mobile getDetails(String mobile) {
		// TODO Auto-generated method stub
		return null;
	}

}
