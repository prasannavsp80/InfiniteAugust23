package com.java.exam;

public abstract class AbstractFactory {
	public abstract Mobile getDetails(String mobile);
}
