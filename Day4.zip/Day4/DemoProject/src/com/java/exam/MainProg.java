package com.java.exam;

public class MainProg {

	public static void main(String[] args) {
		
	}
}
