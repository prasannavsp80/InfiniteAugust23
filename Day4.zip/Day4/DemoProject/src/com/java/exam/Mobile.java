package com.java.exam;

public interface Mobile {

	void name();
	void model();
	void price();
}
