package com.java.day1;

public class CtoF {

	public static void main(String[] args) {
		double c = 37;
		
	}
}
