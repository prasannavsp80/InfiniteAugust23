package com.java.quiz;

public class First {

	public void show() {
		System.out.println("Show Method from class First...");
	}
}
