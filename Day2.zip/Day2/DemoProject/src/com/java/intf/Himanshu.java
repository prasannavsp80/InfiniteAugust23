package com.java.intf;

public class Himanshu implements ITraining {

	@Override
	public void name() {
		System.out.println("Name is Himanshu...");
	}

	@Override
	public void email() {
		System.out.println("Email is himanshu@gmail.com");
	}

}
