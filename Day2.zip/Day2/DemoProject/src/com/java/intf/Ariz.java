package com.java.intf;

public class Ariz implements ITraining {

	@Override
	public void name() {
		System.out.println("Name is Ariz...");
	}

	@Override
	public void email() {
		System.out.println("Email is ariz@gmail.com");
	}

}
