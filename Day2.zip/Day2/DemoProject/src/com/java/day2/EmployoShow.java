package com.java.day2;

public class EmployoShow {

	public static void main(String[] args) {
		Employ employ = new Employ();
		employ.empno = 1;
		employ.name = "Raj";
		employ.basic = 88322;
		
		System.out.println(employ);
	}
}
