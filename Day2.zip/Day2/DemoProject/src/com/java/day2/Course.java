package com.java.day2;

public enum Course {
	JAVA, DOTNET, ANGULAR, REACT
}
