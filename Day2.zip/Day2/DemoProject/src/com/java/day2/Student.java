package com.java.day2;

public class Student {

	int studentId;
	String name;
	Course course;
	double cgp;
}
