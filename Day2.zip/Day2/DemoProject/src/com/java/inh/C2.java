package com.java.inh;

public class C2 extends C1 {

	public C2() {
		System.out.println("Derived Class Constructor...");
	}
}
