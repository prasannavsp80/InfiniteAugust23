package com.java.inh;

public class First {

	public void show() {
		System.out.println("Show Method from Class First...");
	}
}
