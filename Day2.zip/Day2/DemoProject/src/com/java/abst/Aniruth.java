package com.java.abst;

public class Aniruth extends Training {

	@Override
	void name() {
		System.out.println("Name is Aniruth...");
	}

	@Override
	void email() {
		System.out.println("Email is aniruth@gmail.com");
	}

}
