package com.java.abst;

public abstract class Training {
	
	abstract void name();
	abstract void email();
}
