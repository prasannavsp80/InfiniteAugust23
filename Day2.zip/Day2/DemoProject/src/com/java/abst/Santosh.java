package com.java.abst;

public class Santosh extends Training {

	@Override
	void name() {
		System.out.println("Name is Santosh...");
	}

	@Override
	void email() {
		System.out.println("Email is santosh@gmail.com");
	}

}
