package com.java.abst;

public class Ayush extends Employ {

	public Ayush(int empno, String name, double basic) {
		super(empno, name, basic);
	}

}
