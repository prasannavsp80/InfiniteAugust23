package com.java.sup;

public class SupCon {

	public static void main(String[] args) {
		Employ obj1 = new Nitish(1, "Nitish", 88422);
		Employ obj2 = new Aniruth(2, "Aniruth", 88223);
		
		System.out.println(obj1);
		System.out.println(obj2);
	}
}
