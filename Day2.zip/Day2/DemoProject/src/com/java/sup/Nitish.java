package com.java.sup;

public class Nitish extends Employ {

	public Nitish(int empno, String name, double basic) {
		super(empno, name, basic);
		// TODO Auto-generated constructor stub
	}

}
