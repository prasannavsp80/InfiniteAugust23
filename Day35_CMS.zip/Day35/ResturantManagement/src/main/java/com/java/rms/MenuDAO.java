package com.java.rms;

public interface MenuDAO {
	String showMenuDao(int restaurantid, int pageIndex);
}
