package com.java.rms;

import java.util.List;

public interface RestaurantDAO {
	List<Restaurant> showRestaurantsDao();

}
