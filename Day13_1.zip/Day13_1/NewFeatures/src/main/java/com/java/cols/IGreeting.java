package com.java.cols;

@FunctionalInterface
public interface IGreeting {
	void greetMe();
}
