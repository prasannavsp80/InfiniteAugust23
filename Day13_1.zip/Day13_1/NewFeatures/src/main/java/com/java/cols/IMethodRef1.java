package com.java.cols;

@FunctionalInterface
public interface IMethodRef1 {
   void show();
}
