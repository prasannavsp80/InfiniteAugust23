package com.java.cols;

public interface ICalculation {
	int calc(int a, int b);
}
