package com.java.cols;

public interface IMethodRef2 {

	int calc(int x, int y);
}
