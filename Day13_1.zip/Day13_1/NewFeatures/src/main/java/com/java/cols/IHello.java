package com.java.cols;

public interface IHello {

	void show();
}
