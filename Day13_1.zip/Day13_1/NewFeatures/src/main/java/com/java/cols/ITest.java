package com.java.cols;

public interface ITest {
	Emp showEmploy(int empno, String name, double basic);
}
