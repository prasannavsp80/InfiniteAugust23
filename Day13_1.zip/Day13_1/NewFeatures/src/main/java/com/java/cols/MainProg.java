package com.java.cols;

public class MainProg {

	public static void main(String[] args) {
		DemoTest obj = new DemoTest();
		obj.showTest();
	}
}
