package com.java.cols;

public class Demo {

	public void show() {
		System.out.println("Hello World...");
	}
}
